package kr.re.keti.vehicle;

public interface Logger {
    public void log(String msg);
}
