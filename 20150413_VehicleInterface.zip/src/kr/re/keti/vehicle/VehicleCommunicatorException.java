package kr.re.keti.vehicle;

@SuppressWarnings("serial")
public class VehicleCommunicatorException extends java.lang.Exception
{
    public VehicleCommunicatorException()
    {
        super();
    }

    public VehicleCommunicatorException(String s)
    {
        super(s);
    }
}
