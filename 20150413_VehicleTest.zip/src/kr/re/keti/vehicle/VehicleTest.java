package kr.re.keti.vehicle;

//import java.lang.Thread;

public class VehicleTest
{
	public static void main(String args[]) throws Exception
	{
		final String portName = "COM1";
		final int portSpeed = 115200;
		
		RXTX_Serial commModule = new RXTX_Serial();
		
		commModule.open(portName);
		commModule.setSpeed(portSpeed);
		
		ELM327 ifModule = new ELM327();
		
		ifModule.open(commModule);
		
		YFSonata vehicleSonata = new YFSonata(ifModule);
		
		VehicleDataContainer dataContainer = vehicleSonata.getVehicleDataContainer();
		
		vehicleSonata.startAnalyze();
		
		while(true)
		{
			System.out.print("                                                                              \r");
			System.out.print("RPM: " + dataContainer.getEngineRevolution() + ", Light: ");
			
			if(dataContainer.getLight() == VehicleDataContainer.LIGHT_HIGH)
			{
				System.out.print("High");
			}
			else if(dataContainer.getLight() == VehicleDataContainer.LIGHT_ON)
			{
				System.out.print("On");
			}
			else
			{
				System.out.print("Off");
			}
			
			System.out.print(", Door: ");
			
			if(dataContainer.getDoor() == VehicleDataContainer.DOOR_CLOSED)
			{
				System.out.print("Closed");
			}
			else
			{
				System.out.print("Opened");
			}
			
			System.out.print("\r");
			
			Thread.sleep(110);
		}
	}
}
